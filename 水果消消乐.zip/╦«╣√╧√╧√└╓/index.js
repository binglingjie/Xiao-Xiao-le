//��ά����洢ˮ�� 
var M=12;
var N=12;
var fruit=new Array(M);
for(var i=0;i<M;i++){
	fruit[i]=new Array(N); 
	for(var j=0;j<N;j++){
		fruit[i][j]=-1;
	}
}
var click_x=-1;
var click_y=-1;

beginGame();

//��ʼ��Ϸ
function beginGame(){
	clearFruit();
	createDiv();
	createFruitArray();
	fruitIntoDiv();
} 

//����ȫ����-1
function clearFruit(){
	for(var i=0;i<M;i++){
		for(var j=0;j<N;j++){
			fruit[i][j]=-1;
		}
	}
} 

//����M��N��div��ά����
function createDiv(){
	var center=document.createElement("center");
	document.body.appendChild(center);
	var table=document.createElement("table");
	center.appendChild(table);
	for(var i=1;i<M-1;i++){
		var tr=document.createElement("tr");
		table.appendChild(tr);
		for(var j=1;j<N-1;j++){
			var td=document.createElement("td");
			tr.appendChild(td);
			var div=document.createElement("div");
			td.appendChild(div);
			div.id=""+i+"_"+j;
		}
	}
} 

//�������ˮ�����飬�ɶ����� 
function createFruitArray(){
	for(var t=0;t<=9;t++){
		for(var c=1;c<=10;c++){
			var x=Math.floor(Math.random()*10+1);
			var y=Math.floor(Math.random()*10+1);
			if(fruit[x][y]==-1){
				fruit[x][y]=t;
			}
			else{
				while(true){
					y++;
					if(y>10){
						x++;
						y=1;
					}
					if(x>10){
						x=1;
					}
					if(fruit[x][y]==-1){
						fruit[x][y]=t;
						break;	
					}
				}
			}
		}
	}
} 

//��ˮ��ͼƬ����div
function fruitIntoDiv(){
	for(var i=1;i<=M-2;i++){
		for(var j=1;j<=N-2;j++){
			var div=document.getElementById(""+i+"_"+j);
			if(fruit[i][j]!=-1)
				div.innerHTML='<img width="50px" height="50px" src="image/'+fruit[i][j]+'.jpg"/>';
			else
				div.innerHTML='';
			//console.log(fruit[i][j]+" ");
		}
		//console.log("\n");
	}
} 

//�û������ˮ�� 
document.onclick=Hanlder;
function Hanlder(e)
{
    e=e||event||window.event;
    var tag=e.srcElement||e.target;
    var div=tag.parentNode;
    if(div.tagName!="DIV")
    	return;
    var s=div.id.split("_");
    var i=parseInt(s[0]);
    var j=parseInt(s[1]);
    if(click_x==-1&&click_y==-1){
		click_x=i;
		click_y=j;
	}else if(click_x==i&&click_y==j){
		
	}else if(fruit[i][j]==fruit[click_x][click_y]){
		if(tryLine(i,j,click_x,click_y)){
			fruit[i][j]=-1;
			fruit[click_x][click_y]=-1;
			click_x=-1;
			click_y=-1;
			fruitIntoDiv();
			if(isOver()){
				alert("��ϲͨ�أ�");
			}
		}else{
			click_x=i;
			click_y=j;
		}
	}
	else{
		click_x=i;
		click_y=j;
	}
}

//������������ˮ��
function tryLine_1(x1,y1,x2,y2){
	if(x1==x2&&y1>y2){
		for(var y=y1-1;y>y2;y--){
			if(fruit[x1][y]!=-1){
				return false;
			}
		}
		return true;
	}
	else if(x1==x2&&y1<y2){
		return tryLine_1(x2,y2,x1,y1);
	}
	if(y1==y2&&x1<x2){
		for(var x=x1+1;x<x2;x++){
			if(fruit[x][y1]!=-1){
				return false;
			}
		}
		return true;
	}
	else if(y1==y2&&x1>x2){
		return tryLine_1(x2,y2,x1,y1);
	}
} 

function tryLine_2(x1,y1,x2,y2){
	return tryLine_1(x1,y1,x1,y2)&&fruit[x1][y2]==-1&&tryLine_1(x1,y2,x2,y2)||tryLine_1(x1,y1,x2,y1)&&fruit[x2][y1]==-1&&tryLine_1(x2,y1,x2,y2);
}

function tryLine_3(x1,y1,x2,y2){
	for(var i=x1-1;i>=0;i--){
		if(fruit[i][y1]!=-1){
			break;
		}
		else if(tryLine_2(i,y1,x2,y2)){
			return true;
		}
	}
	for(var i=x1+1;i<=11;i++){
		if(fruit[i][y1]!=-1){
			break;
		}
		else if(tryLine_2(i,y1,x2,y2)){
			return true;
		}
	}
	for(var j=y1-1;j>=0;j--){
		if(fruit[x1][j]!=-1){
			break;
		}
		else if(tryLine_2(x1,j,x2,y2)){
			return true;
		}
	}
	for(var j=y1+1;j<=11;j++){
		if(fruit[x1][j]!=-1){
			break;
		}
		else if(tryLine_2(x1,j,x2,y2)){
			return true;
		}
	}
}

//��������ˮ�� 
function tryLine(x1,x2,y1,y2){
	return tryLine_1(x1,x2,y1,y2)||tryLine_2(x1,x2,y1,y2)||tryLine_3(x1,x2,y1,y2);
}

//�ж��Ƿ��Ѿ���ȫ����
function isOver(){
	for(var i=1;i<M-1;i++){
		for(var j=1;j<N-1;j++){
			if(fruit[i][j]!=-1){
				return false;
			}
		}
	}
	return true;
} 
